# Wildlife Ecology Practice Hub

A responsive, static quiz website built from the uploaded `merged.pdf`.

## What's included
- 12 assignment cards and question navigation
- Questions and answer options extracted from the PDF
- Single-question practice, mixed practice, bookmarks, and local progress
- Export/import of browser progress
- Responsive desktop/mobile design

## Important source note
The uploaded PDF is titled "Assignment Solutions", but the extracted pages show questions and answer options without visibly marked correct answers or explanations. To avoid inventing an answer key, `answer` is currently `null` for each question. Add verified answers in `questions.js` using the option label (`"a"`, `"b"`, `"c"`, or `"d"`) and a short explanation if you have one.

The PDF appears to omit the Week 6 heading; questions on pages 13–14 are grouped as Assignment 6 because they sit between Week 5 and Week 7.

## Run locally
You can simply open `index.html` in a modern browser. If the browser blocks local JavaScript files, run a tiny local server:
- Install Python 3
- Open a terminal in this folder
- Run `python -m http.server 8000`
- Visit `http://localhost:8000`

## Deploy on Vercel
1. Extract this ZIP.
2. Create a GitHub repository and upload `index.html` and `questions.js`.
3. In Vercel, choose **Add New → Project** and import the repository.
4. Framework preset: **Other**; build command: leave blank; output directory: `.`.
5. Deploy. The generated public URL will be shareable.

This is an independent study tool, not an official NPTEL website. Keep course materials within applicable copyright and sharing rules.
